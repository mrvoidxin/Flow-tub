package io.github.aedev.flow.data.subscriptions

import android.util.Log
import androidx.room.withTransaction
import io.github.aedev.flow.data.innertube.RssSubscriptionService
import io.github.aedev.flow.data.local.AppDatabase
import io.github.aedev.flow.data.local.PlayerPreferences
import io.github.aedev.flow.data.local.SubscriptionRepository
import io.github.aedev.flow.data.local.dao.CacheDao
import io.github.aedev.flow.data.local.entity.SubscriptionFeedEntity
import io.github.aedev.flow.data.model.Video
import io.github.aedev.flow.data.model.VideoCollaborator
import io.github.aedev.flow.data.subscriptions.SubscriptionFeedMerger.preservingEnrichedMetadata
import io.github.aedev.flow.utils.PerformanceDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

/** One progressive step of a refresh, as the caller should render it. */
data class SubscriptionFeedRefreshProgress(
    val videos: List<Video>,
    val failedChannelIds: Set<String>,
    val failedChannelReasons: Map<String, String>,
    val processedChannels: Int,
    val totalChannels: Int,
)

/**
 * The single owner of the subscription feed cache.
 *
 * Every trigger — opening the screen, the periodic in-screen refresh, app startup and the
 * background new-upload check — goes through here, so there is one staleness policy, one merge
 * implementation and one writer for `subscription_feed_cache`.
 */
@Singleton
class SubscriptionFeedRepository
    @Inject
    constructor(
        private val subscriptionRepository: SubscriptionRepository,
        private val rssSubscriptionService: RssSubscriptionService,
        private val cacheDao: CacheDao,
        private val database: AppDatabase,
        private val playerPreferences: PlayerPreferences,
        private val collabIndex: ChannelCollabIndex,
    ) {
        /**
         * Guards against overlapping refreshes; the screen, the startup pass and the worker can all
         * fire within the same second, and a second sweep would only duplicate the first one's work.
         */
        private val refreshLock = Mutex()

        fun observeFeed(): Flow<List<Video>> =
            combine(cacheDao.getSubscriptionFeed(), playerPreferences.subscriptionCollaborationsEnabled) { rows, collaborations ->
                rows.filter { collaborations || it.feedChannelId.isEmpty() }.map { it.toVideo() }
            }

        /** Which channels are due a refresh right now; empty when everything is still fresh. */
        suspend fun planRefresh(force: Boolean): SubscriptionRefreshPlan {
            val subscriptions = subscriptionRepository.getAllSubscriptions().first()
            return SubscriptionRefreshPlanner.plan(
                subscriptions = subscriptions,
                now = System.currentTimeMillis(),
                force = force,
            )
        }

        /**
         * Runs [plan] and writes the result. Emits a progressively more complete feed so the caller
         * can render partial results; the cache is written once, when the fetch finishes.
         *
         * Emits nothing at all when the plan is empty or another refresh already holds the lock.
         */
        fun refresh(plan: SubscriptionRefreshPlan): Flow<SubscriptionFeedRefreshProgress> =
            flow {
                if (plan.isEmpty) return@flow
                if (!refreshLock.tryLock()) {
                    Log.d(TAG, "Skip refresh: another subscription refresh is running")
                    return@flow
                }

                try {
                    val cachedRows = withContext(PerformanceDispatcher.diskIO) { cacheDao.getSubscriptionFeed().first() }
                    val allCached = cachedRows.map { it.toVideo() }
                    val lastFeedFetchAt =
                        withContext(PerformanceDispatcher.diskIO) {
                            subscriptionRepository.getAllSubscriptions().first().associate { it.channelId to it.lastFeedFetchAt }
                        }
                    val plannedChannelIds = plan.channelIds.toHashSet()
                    val sliceCached =
                        if (plan.isFullRefresh) {
                            allCached
                        } else {
                            allCached.filter { it.channelId in plannedChannelIds }
                        }

                    var previewVideos = allCached
                    var latestChunkVideos = emptyList<Video>()
                    var failedChannelIds = emptySet<String>()
                    var failedChannelReasons = emptyMap<String, String>()
                    var incompleteChannelIds = emptySet<String>()
                    var processed = 0

                    rssSubscriptionService
                        .fetchSubscriptionVideos(
                            channelIds = plan.channelIds,
                            maxTotal = MAX_SUBSCRIPTION_CACHE_ITEMS,
                            knownVideoIds = if (plan.isFullRefresh) emptySet() else allCached.mapTo(HashSet()) { it.id },
                            storedReelVerdicts = trustedReelVerdicts(cachedRows, lastFeedFetchAt),
                            onProgress = { done, _ -> processed = done },
                        ).collect { chunk ->
                            failedChannelIds = chunk.failedChannelIds
                            failedChannelReasons = chunk.failedChannelReasons
                            incompleteChannelIds = chunk.incompleteChannelIds
                            if (chunk.videos.isNotEmpty()) {
                                latestChunkVideos = chunk.videos
                                previewVideos =
                                    SubscriptionFeedMerger
                                        .mergeSubscriptionFeed(
                                            freshVideos = chunk.videos,
                                            cachedVideos = previewVideos,
                                            now = System.currentTimeMillis(),
                                            windowMs = SUBSCRIPTION_CACHE_WINDOW_MS,
                                            maxItems = MAX_SUBSCRIPTION_CACHE_ITEMS,
                                        ).withHighQualityThumbnails()
                            }
                            emit(
                                SubscriptionFeedRefreshProgress(
                                    videos = previewVideos,
                                    failedChannelIds = failedChannelIds,
                                    failedChannelReasons = failedChannelReasons,
                                    processedChannels = processed,
                                    totalChannels = plan.channelIds.size,
                                ),
                            )
                        }

                    val refreshTime = System.currentTimeMillis()
                    if (latestChunkVideos.isNotEmpty() || plan.isFullRefresh) {
                        val persisted =
                            persist(
                                plan = plan,
                                freshVideos = latestChunkVideos,
                                sliceCached = sliceCached,
                                failedChannelIds = failedChannelIds + incompleteChannelIds,
                                refreshTime = refreshTime,
                            )
                        emit(
                            SubscriptionFeedRefreshProgress(
                                videos = persisted,
                                failedChannelIds = failedChannelIds,
                                failedChannelReasons = failedChannelReasons,
                                processedChannels = plan.channelIds.size,
                                totalChannels = plan.channelIds.size,
                            ),
                        )
                    } else if (allCached.isNotEmpty()) {
                        withContext(PerformanceDispatcher.diskIO) {
                            playerPreferences.setSubscriptionLastRefresh(refreshTime, allCached.size)
                        }
                    }
                    if (refreshCollaborations()) {
                        emit(
                            SubscriptionFeedRefreshProgress(
                                videos = withContext(PerformanceDispatcher.diskIO) { loadCachedFeed() },
                                failedChannelIds = failedChannelIds,
                                failedChannelReasons = failedChannelReasons,
                                processedChannels = plan.channelIds.size,
                                totalChannels = plan.channelIds.size,
                            ),
                        )
                    }
                } finally {
                    refreshLock.unlock()
                }
            }

        /**
         * Splices the fetched channels back into the cache. A full refresh still replaces the table
         * outright; an incremental one only touches the rows of the channels it actually fetched, so
         * an unrelated channel's items are never dropped by a partial run.
         */
        private suspend fun persist(
            plan: SubscriptionRefreshPlan,
            freshVideos: List<Video>,
            sliceCached: List<Video>,
            failedChannelIds: Set<String>,
            refreshTime: Long,
        ): List<Video> {
            val subscribedChannelIds =
                withContext(PerformanceDispatcher.diskIO) {
                    subscriptionRepository.getAllSubscriptions().first().mapTo(HashSet()) { it.channelId }
                }
            val write =
                subscriptionFeedWrite(
                    plan = plan,
                    freshVideos = freshVideos,
                    cachedSlice = sliceCached,
                    failedChannelIds = failedChannelIds,
                    subscribedChannelIds = subscribedChannelIds,
                    now = refreshTime,
                    windowMs = SUBSCRIPTION_CACHE_WINDOW_MS,
                    maxItems = MAX_SUBSCRIPTION_CACHE_ITEMS,
                )

            val entities = write.rows.map { it.toEntity(refreshTime) }
            withContext(PerformanceDispatcher.diskIO) {
                database.withTransaction {
                    if (plan.isFullRefresh) {
                        cacheDao.clearSubscriptionUploads()
                    } else {
                        plan.channelIds.chunked(SQLITE_VARIABLE_LIMIT).forEach { ids ->
                            cacheDao.deleteSubscriptionFeedForChannels(ids)
                        }
                    }
                    cacheDao.insertSubscriptionFeed(entities)
                    cacheDao.pruneSubscriptionFeedOlderThan(refreshTime - SUBSCRIPTION_CACHE_WINDOW_MS)
                }
                subscriptionRepository.markFeedFetched(write.fetchedChannelIds, refreshTime)
                val cachedCount = cacheDao.getSubscriptionFeedCount()
                playerPreferences.setSubscriptionLastRefresh(refreshTime, cachedCount)
            }
            Log.i(
                TAG,
                "Persisted ${entities.size} rows for ${plan.channelIds.size} channels " +
                    "(full=${plan.isFullRefresh}, failed=${failedChannelIds.size})",
            )

            return if (plan.isFullRefresh) write.rows else loadCachedFeed()
        }

        /**
         * Adds videos the background new-upload check discovered, without disturbing rows the feed
         * has already enriched. The channel is deliberately *not* marked as fetched: RSS alone
         * cannot see livestreams, so the feed still owes it a full pass.
         *
         * [reelVideoIds] is the caller's reel verdict for these entries. RSS marks none of them, so
         * without it every seeded reel reaches the feed as an ordinary upload and stays there until
         * the channel's next full refresh — visible even with Shorts switched off (#903).
         */
        suspend fun seedFromNotificationCheck(
            channelId: String,
            channelName: String?,
            entries: List<ChannelRssEntry>,
            reelVideoIds: Set<String> = emptySet(),
        ) {
            if (entries.isEmpty()) return
            val now = System.currentTimeMillis()
            val cutoff = now - SUBSCRIPTION_CACHE_WINDOW_MS
            val rows =
                entries
                    .filter { it.publishedAtMillis > cutoff }
                    .map { entry ->
                        entry.toEntity(
                            channelId = channelId,
                            channelName = channelName,
                            cachedAt = now,
                            isShort = entry.videoId in reelVideoIds,
                        )
                    }
            if (rows.isEmpty()) return

            withContext(PerformanceDispatcher.diskIO) {
                cacheDao.insertSubscriptionFeedIfAbsent(rows)
            }
            Log.d(TAG, "Seeded ${rows.size} row(s) for $channelId from the notification check")
        }

        /** Writes back metadata the on-demand player lookup resolved for already-cached rows. */
        suspend fun updateEnrichedMetadata(videos: Collection<Video>) {
            if (videos.isEmpty()) return
            withContext(PerformanceDispatcher.diskIO) {
                database.withTransaction {
                    videos.forEach { video ->
                        cacheDao.updateSubscriptionFeedMetadata(
                            videoId = video.id,
                            title = video.title,
                            channelName = video.channelName,
                            channelId = video.channelId,
                            thumbnailUrl = video.thumbnailUrl,
                            duration = video.duration,
                            viewCount = video.viewCount,
                            // The cache has no column for a scheduled stream, so it is stored as
                            // live + upcoming and read back the same way.
                            isLive = video.isLive || video.isScheduledLive,
                            isUpcoming = video.isUpcoming,
                            uploadDate = video.uploadDate,
                            timestamp = video.timestamp,
                            timestampIsExact = video.timestampIsExact,
                        )
                    }
                }
            }
        }

        /**
         * Uploads Home read from channel tabs. A row RSS already stored keeps its exact publish time
         * and gains the length and counts RSS cannot give; an upload RSS has not seen yet is added.
         * The channel is not marked fetched, so the feed's own refresh schedule is unchanged.
         */
        suspend fun mergeChannelTabUploads(uploads: List<Video>) {
            if (uploads.isEmpty()) return
            val now = System.currentTimeMillis()
            val recent = uploads.filter { it.timestamp > now - SUBSCRIPTION_CACHE_WINDOW_MS }
            if (recent.isEmpty()) return
            val stored = withContext(PerformanceDispatcher.diskIO) { loadCachedFeed() }
            val (inserts, updates) = splitChannelTabUploads(recent, stored)
            withContext(PerformanceDispatcher.diskIO) {
                cacheDao.insertSubscriptionFeedIfAbsent(inserts.map { it.toEntity(now) })
            }
            updateEnrichedMetadata(updates)
        }

        private suspend fun loadCachedFeed(): List<Video> = observeFeed().first()

        /**
         * Looks a few followed channels over for collaborations someone else uploaded and stores what
         * each one shows, replacing that channel's earlier set. With the setting off, drops them all.
         * True when the stored feed changed.
         */
        private suspend fun refreshCollaborations(): Boolean {
            if (!playerPreferences.subscriptionCollaborationsEnabled.first()) {
                withContext(PerformanceDispatcher.diskIO) { cacheDao.deleteCollaborations() }
                return false
            }
            val followed =
                withContext(PerformanceDispatcher.diskIO) {
                    subscriptionRepository.getAllSubscriptions().first().map { it.channelId }
                }
            val found = collabIndex.scan(followed)
            if (found.isEmpty()) return false
            val now = System.currentTimeMillis()
            withContext(PerformanceDispatcher.diskIO) {
                found.forEach { (feedChannelId, collabs) ->
                    val recent = collabs.filter { it.timestamp > now - SUBSCRIPTION_CACHE_WINDOW_MS }
                    cacheDao.replaceCollaborations(feedChannelId, recent.map { it.toEntity(now, feedChannelId) })
                }
            }
            Log.i(TAG, "Collaborations: looked at ${found.size} channel(s), ${found.values.sumOf { it.size }} video(s)")
            return true
        }

        private companion object {
            const val TAG = "SubsFeedRepo"
            const val SUBSCRIPTION_FEED_LOOKBACK_DAYS = 60L
            const val SUBSCRIPTION_CACHE_WINDOW_MS = SUBSCRIPTION_FEED_LOOKBACK_DAYS * 24L * 60L * 60L * 1000L
            const val MAX_SUBSCRIPTION_CACHE_ITEMS = 1500

            /** SQLite allows 999 bound variables per statement; stay comfortably below it. */
            const val SQLITE_VARIABLE_LIMIT = 500
        }
    }

/** New rows to add, and stored rows with the tab's length and counts but their own publish time. */
internal fun splitChannelTabUploads(
    uploads: List<Video>,
    stored: List<Video>,
): Pair<List<Video>, List<Video>> {
    val byId = stored.associateBy { it.id }
    val (known, unseen) = uploads.partition { it.id in byId }
    return unseen to known.map { byId.getValue(it.id).preservingEnrichedMetadata(it) }
}

private fun SubscriptionFeedEntity.toVideo() =
    Video(
        id = videoId,
        title = title,
        channelName = channelName,
        channelId = channelId,
        thumbnailUrl = thumbnailUrl,
        duration = duration,
        viewCount = viewCount,
        uploadDate = uploadDate,
        timestamp = timestamp,
        timestampIsExact = timestampIsExact,
        channelThumbnailUrl = channelThumbnailUrl,
        collaborators = decodeCollaborators(collaboratorsJson),
        channelThumbnailUrls = decodeCollaborators(collaboratorsJson).map { it.thumbnailUrl }.filter { it.isNotBlank() },
        isShort = isShort,
        isLive = isLive && uploadDate.containsLiveMarker(),
        // A cached "upcoming" outlives its start time only until the next look at the row.
        isUpcoming = isUpcoming && timestamp > System.currentTimeMillis(),
        isScheduledLive = isUpcoming && isLive && timestamp > System.currentTimeMillis(),
    )

private fun Video.toEntity(
    cachedAtMillis: Long,
    feedChannelId: String = "",
) = SubscriptionFeedEntity(
    videoId = id,
    title = title,
    channelName = channelName,
    channelId = channelId,
    thumbnailUrl = thumbnailUrl,
    duration = duration,
    viewCount = viewCount,
    uploadDate = uploadDate,
    timestamp = timestamp,
    channelThumbnailUrl = channelThumbnailUrl,
    isShort = isShort,
    isLive = isLive,
    isUpcoming = isUpcoming,
    cachedAt = cachedAtMillis,
    feedChannelId = feedChannelId,
    collaboratorsJson = if (collaborators.size > 1) collaboratorJson.encodeToString(collaborators) else "",
    timestampIsExact = timestampIsExact,
)

private val collaboratorJson = Json { ignoreUnknownKeys = true }

private fun decodeCollaborators(json: String): List<VideoCollaborator> =
    if (json.isBlank()) {
        emptyList()
    } else {
        runCatching {
            collaboratorJson.decodeFromString<List<VideoCollaborator>>(json)
        }.getOrDefault(emptyList())
    }

private fun ChannelRssEntry.toEntity(
    channelId: String,
    channelName: String?,
    cachedAt: Long,
    isShort: Boolean,
) = SubscriptionFeedEntity(
    videoId = videoId,
    title = title,
    channelName = channelName.orEmpty(),
    channelId = channelId,
    thumbnailUrl =
        io.github.aedev.flow.utils.ThumbnailUrlResolver
            .normalizeVideoThumbnail(videoId, thumbnailUrl),
    // RSS carries neither; the feed's on-demand enrichment fills them in when the item is shown.
    duration = 0,
    viewCount = viewCount,
    uploadDate = "",
    timestamp = publishedAtMillis,
    timestampIsExact = true,
    channelThumbnailUrl = "",
    isShort = isShort,
    isLive = false,
    isUpcoming = publishedAtMillis > cachedAt + 60_000L,
    cachedAt = cachedAt,
)

private fun String.containsLiveMarker(): Boolean {
    val text = lowercase()
    return text.contains("live") ||
        text.contains("stream") ||
        text.contains("watching") ||
        text.contains("started")
}

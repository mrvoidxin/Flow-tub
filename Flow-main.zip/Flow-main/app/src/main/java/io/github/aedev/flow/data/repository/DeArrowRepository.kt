package io.github.aedev.flow.data.repository

import android.util.LruCache
import com.google.gson.Gson
import io.github.aedev.flow.data.model.DeArrowContent
import io.github.aedev.flow.data.model.DeArrowResult
import io.github.aedev.flow.network.AppProxyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

/**
 * Fetches DeArrow branding data from the SponsorBlock API.
 *
 * DeArrow replaces clickbait titles and thumbnails with community-submitted,
 * more accurate alternatives. See https://dearrow.ajay.app/
 *
 * Results are cached in-memory (LRU, 200 entries) to prevent redundant network calls.
 */
object DeArrowRepository {
    private val client: OkHttpClient
        get() = AppProxyManager.applyTo(OkHttpClient.Builder()).build()
    private val gson = Gson()

    private const val BRANDING_BASE_URL = "https://sponsor.ajay.app/api/branding"
    private const val THUMBNAIL_BASE_URL = "https://dearrow-thumb.ajay.app/api/v1/getThumbnail"

    /**
     * LRU cache mapping videoId -> DeArrowResult (null = fetched but no useful data).
     * Capacity: 200 entries ≈ a few home page loads.
     */
    private val cache = LruCache<String, Optional<DeArrowResult>>(200)

    /** Wrapper to distinguish "cache miss" from "cached null" */
    private class Optional<T>(
        val value: T?,
    )

    /**
     * Returns the DeArrow result for [videoId], or null if:
     *  - DeArrow has no data for this video
     *  - The network request failed
     *
     * Results are cached so the same video is only fetched once per session.
     */
    suspend fun getDeArrowResult(videoId: String): DeArrowResult? =
        withContext(Dispatchers.IO) {
            // Cache hit
            cache.get(videoId)?.let { return@withContext it.value }

            try {
                val request =
                    Request
                        .Builder()
                        .url("$BRANDING_BASE_URL?videoID=$videoId")
                        .header("User-Agent", "FlowYouTube/1.0")
                        .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext null
                    }
                    val body = response.body?.string()
                    if (body.isNullOrBlank()) {
                        cache.put(videoId, Optional(null))
                        return@withContext null
                    }
                    val parsed = parseResponse(body, videoId)
                    cache.put(videoId, Optional(parsed))
                    return@withContext parsed
                }
            } catch (e: Exception) {
                return@withContext null
            }
        }

    fun getCachedDeArrowResult(videoId: String): DeArrowResult? = cache.get(videoId)?.value

    private fun parseResponse(
        json: String,
        videoId: String,
    ): DeArrowResult? =
        try {
            val content = gson.fromJson(json, DeArrowContent::class.java)
            extractResult(content, videoId)
        } catch (e: Exception) {
            null
        }

    /**
     * Picks the best title and thumbnail from [content]:
     * - Prefers locked entries (manually verified) over voted ones
     * - Ignores entries with negative votes (downvoted)
     * - Ignores "original" entries (these just mean "keep as-is")
     */
    private fun extractResult(
        content: DeArrowContent,
        videoId: String,
    ): DeArrowResult? {
        val title =
            content.titles
                .filter { !it.original && (it.votes >= 0 || it.locked) }
                .maxByOrNull { if (it.locked) Int.MAX_VALUE else it.votes }
                ?.title
                ?.let(::stripCaseMarkers)

        val bestThumb =
            content.thumbnails
                .filter { !it.original && (it.votes >= 0 || it.locked) }
                .maxByOrNull { if (it.locked) Int.MAX_VALUE else it.votes }

        val thumbnailUrl =
            when {
                bestThumb?.thumbnail != null -> {
                    bestThumb.thumbnail
                }

                bestThumb?.timestamp != null -> {
                    "$THUMBNAIL_BASE_URL?videoID=$videoId&time=${bestThumb.timestamp}"
                }

                else -> {
                    null
                }
            }

        return if (title == null && thumbnailUrl == null) {
            null
        } else {
            DeArrowResult(title = title, thumbnailUrl = thumbnailUrl)
        }
    }

    /** Removes a cached entry, forcing a fresh fetch next time. */
    fun invalidate(videoId: String) {
        cache.remove(videoId)
    }

    /** Clears the entire in-memory cache. */
    fun clearCache() {
        cache.evictAll()
    }
}

/**
 * DeArrow submitters prefix a word with `>` to keep its casing when titles are auto-formatted; the
 * marker is formatting metadata, never part of the title.
 */
internal fun stripCaseMarkers(title: String): String =
    buildString(title.length) {
        var atWordStart = true
        title.forEachIndexed { i, c ->
            val isMarker =
                c == '>' && atWordStart &&
                    title.getOrNull(i + 1)?.isWhitespace() == false
            if (!isMarker) append(c)
            atWordStart = c.isWhitespace()
        }
    }
